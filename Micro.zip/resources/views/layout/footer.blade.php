
    <div class="footer "  data-aos="fade-up">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-4">
                    <div class="footer-contact">
                        <h2>Office Contact</h2>
                        <p><i class="fa fa-phone-alt"></i>+91 7874747616</p>
                        <p><i class="fa fa-envelope"></i>www.diamondandcbnwheels.in<br>sales@diamondandcbnwheels.in
                        <p><i class="fa fa-map-marker-alt"></i>A/22, Shreenath Park, Wonder Point,C.T.M,Ahmedabad-380026. Guj. (INDIA).</p>

                        </p>
                       
                    </div>
                </div>
                <div class="col-md-6 col-lg-5">
                    <div class="footer-link">
                        <h2>Services Areas</h2>
                        <a href="{{route('Resin')}}">Resin Bonded Diamond & CBN wheels</a>
                        <a href="{{route('Hybrid')}}">Hybrid Bonded Diamond & CBN wheels</a>
                        <a href="{{route('Vitrified')}}">Vitrified Bonded Diamond & CBN wheels</a>

                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="footer-link">
                        <h2>Useful Pages</h2>
                        <a href="{{route('home.index')}}">Home</a>
                        <a href="{{route('about')}}">About Us</a>
                        <div class="footer-product-dropdown">
                            <a class="footer-product" href="{{route('product')}}">Products</a>

                        </div>


                        <a href="{{ route('contact') }}">Contact Us</a>



                    </div>
                </div>

            </div>
        </div>

        <div class="container copyright">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; <a href="#">MICRO</a>, All Right Reserved.</p>
                </div>
            </div>
        </div>
    </div>



